// One of the 32 output columns in the original 8-input dot bank.
module fpga_mxm_column(
 input logic format_bf16_i,
 input logic [127:0] activation_bits_i,weight_bits_i,
 output logic [31:0] partial_value_o
);
 import lpu_vxm_math_pkg::*;
 function automatic [31:0] decode_16(input logic [15:0] x,input logic fmt);
   decode_16=fmt?{x,16'b0}:fp16_to_fp32(x);
 endfunction
 always_comb begin
   partial_value_o=0;
   for(integer lane=0;lane<8;lane++)
     partial_value_o=fp32_add_rne(partial_value_o,
       fp32_multiply_rne(decode_16(activation_bits_i[lane*16+:16],format_bf16_i),
                         decode_16(weight_bits_i[lane*16+:16],format_bf16_i)));
 end
endmodule
